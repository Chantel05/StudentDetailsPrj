﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;        //Add namespace

namespace CreateAndWriteToFile
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Specify the path that the file is created to and written
            string path = @"D:\Users\27671\Desktop\files\file1.txt";

            //Using Exception Handling
            try
            {
                //utilize StreamWriter class to create object and writes to the textfile 
                using (StreamWriter writer = new StreamWriter(path))
                {
                    writer.WriteLine("Welcome to PRG282");
                    writer.Write("This is a...");
                    writer.WriteLine("...contact class");
                    writer.WriteLine("");
                    writer.WriteLine("Goodbye");
                }
                Console.WriteLine("Operation successful. Check file in folder"); //Writes to console
            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Could not write to file");
            }
            
            Console.ReadLine();
        }
    }
}
